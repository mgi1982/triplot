Extensons in this folder will be enabled
on the Windows Azure role instance.