<?php

namespace WindowsAzure\TaskDemoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;
use Symfony\Component\DependencyInjection\ContainerBuilder;

class WindowsAzureTaskDemoBundle extends Bundle
{
}
