<?php

require_once __DIR__ . "/../vendor/.composer/autoload.php";

require_once __DIR__ . "/Beberlei/Tests/AzureBlobStorage/BlobTestCase.php";

error_reporting(-1);
